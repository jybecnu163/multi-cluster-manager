package com.cloudplatform.manager.service;

import com.cloudplatform.manager.base.BaseServiceTest;
import com.cloudplatform.manager.mapper.UserMapper;
import com.cloudplatform.manager.model.entity.User;
import com.cloudplatform.manager.service.impl.AuthServiceImpl;
import com.cloudplatform.manager.util.JwtUtil;
import com.cloudplatform.manager.util.RedisUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class AuthServiceTest extends BaseServiceTest {

    @Mock
    private UserMapper userMapper;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private JwtUtil jwtUtil;
    @Mock
    private RedisUtil redisUtil;

    @InjectMocks
    private AuthServiceImpl authService;

    private User mockUser;

    @BeforeEach
    void setUp() {
        mockUser = new User();
        mockUser.setId(1L);
        mockUser.setEmail("admin@test.com");
        mockUser.setPasswordHash("$2a$10$hash");
    }

    @Test
    @DisplayName("登录成功 - 返回JWT")
    void loginSuccess() {
        when(userMapper.findByEmail(anyString())).thenReturn(Optional.ofNullable(mockUser));
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);
        when(jwtUtil.generateToken(anyLong(), anyString())).thenReturn("mock-token");

        String result = authService.login("admin@test.com", "Admin@123456");
        assertNotNull(result);
        assertEquals("mock-token", result);
    }

    @Test
    @DisplayName("登录失败 - 密码错误")
    void loginFailWrongPassword() {
        when(userMapper.findByEmail(anyString())).thenReturn(Optional.ofNullable(mockUser));
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(false);

        assertThrows(RuntimeException.class, () ->
                authService.login("admin@test.com", "wrong"));
    }

    @Test
    @DisplayName("注销成功 - token加入黑名单")
    void logoutSuccess() {
        authService.logout("some-token");
        // 验证 redisUtil.blacklistToken 被调用
    }
}