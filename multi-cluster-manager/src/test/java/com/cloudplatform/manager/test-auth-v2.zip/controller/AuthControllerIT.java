package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseControllerIT;
import com.cloudplatform.manager.service.AuthService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class AuthControllerIT extends BaseControllerIT {

    @MockBean
    private AuthService authService;

    @Nested
    @DisplayName("POST /auth/login")
    class Login {
        @Test
        @DisplayName("正确凭据返回200及token")
        void success() throws Exception {
            when(authService.login(any(), any()))
                    .thenReturn(Map.of("access_token", "jwt", "token_type", "Bearer", "expires_in", 28800).toString());
            mockMvc.perform(post("/api/v1/auth/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"email\":\"admin@test.com\",\"password\":\"Admin@123456\"}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.access_token").value("jwt"));
        }

        @Test
        @DisplayName("缺少email返回400")
        void missingEmail() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"password\":\"12345678\"}"))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @DisplayName("无效邮箱格式返回400")
        void invalidEmail() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"email\":\"invalid\",\"password\":\"12345678\"}"))
                    .andExpect(status().isBadRequest());
        }
    }

    @Nested
    @DisplayName("POST /auth/logout")
    class Logout {
        @Test
        @DisplayName("携带有效token返回204")
        void success() throws Exception {
            mockMvc.perform(post("/api/v1/auth/logout")
                    .header("Authorization", "Bearer valid-token"))
                    .andExpect(status().isNoContent());
        }

        @Test
        @DisplayName("无token返回401")
        void withoutToken() throws Exception {
            mockMvc.perform(post("/api/v1/auth/logout"))
                    .andExpect(status().isUnauthorized());
        }
    }
}