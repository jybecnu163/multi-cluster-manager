package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseControllerIT;
import com.cloudplatform.manager.model.entity.Company;
import com.cloudplatform.manager.service.CompanyService;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CompanyControllerIT extends BaseControllerIT {

    @MockBean
    private CompanyService companyService;

    @Test
    @WithMockUser(roles = {"ADMIN"})
    @DisplayName("创建公司 - 管理员返回201")
    void createCompanyAsAdmin() throws Exception {
        when(companyService.createCompany(any())).thenReturn(new Company());
        mockMvc.perform(post("/api/v1/companies")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"测试公司\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.name").value("测试公司"));
    }

    @Test
    @WithMockUser(roles = {"DEV"})
    @DisplayName("创建公司 - 开发返回403")
    void createCompanyForbidden() throws Exception {
        mockMvc.perform(post("/api/v1/companies")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"test\"}"))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("未认证访问返回401")
    void unauthenticated() throws Exception {
        mockMvc.perform(get("/api/v1/companies"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    @DisplayName("删除有依赖公司返回409")
    void deleteConflict() throws Exception {
        when(companyService.deleteCompany(1L)).thenThrow(new RuntimeException("has departments"));
        mockMvc.perform(delete("/api/v1/companies/1"))
                .andExpect(status().isConflict());
    }
}