package com.cloudplatform.manager.service;

import com.cloudplatform.manager.base.BaseServiceTest;
import com.cloudplatform.manager.mapper.DepartmentMapper;
import com.cloudplatform.manager.mapper.DepartmentSettingsMapper;
import com.cloudplatform.manager.model.entity.Department;
import com.cloudplatform.manager.model.entity.DepartmentSettings;
import com.cloudplatform.manager.service.impl.DepartmentServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class DepartmentServiceTest extends BaseServiceTest {

    @Mock
    private DepartmentMapper departmentMapper;
    @Mock
    private DepartmentSettingsMapper settingsMapper;
    @InjectMocks
    private DepartmentServiceImpl departmentService;

    @Test
    @DisplayName("创建部门成功")
    void createDepartment() {
        Department dept = new Department();
        dept.setName("研发部");
        dept.setCompanyId(1L);
        when(departmentMapper.insert(any())).thenReturn(1);
        assertDoesNotThrow(() ->
                departmentService.createDepartment(dept.getCompanyId(), dept.getName(), dept.getDirectorUserId()));
    }

    @Test
    @DisplayName("获取部门设置")
    void getSettings() {
        when(settingsMapper.selectById(any())).thenReturn(new DepartmentSettings());
        assertNotNull(departmentService.getSettings(1L));
    }
}