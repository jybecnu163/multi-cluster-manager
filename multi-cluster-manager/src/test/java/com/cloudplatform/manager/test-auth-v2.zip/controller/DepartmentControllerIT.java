package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseControllerIT;
import com.cloudplatform.manager.service.DepartmentService;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class DepartmentControllerIT extends BaseControllerIT {

    @MockBean
    private DepartmentService departmentService;

    @Test
    @WithMockUser(roles = {"ADMIN"})
    @DisplayName("创建部门返回201")
    void createDepartment() throws Exception {
        mockMvc.perform(post("/api/v1/departments")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"company_id\":1,\"name\":\"研发部\"}"))
                .andExpect(status().isCreated());
    }

    @Test
    @WithMockUser(roles = {"DIRECTOR"})
    @DisplayName("获取部门设置返回200")
    void getSettings() throws Exception {
        mockMvc.perform(get("/api/v1/departments/1/settings"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = {"DEV"})
    @DisplayName("开发修改部门设置返回403")
    void devCannotUpdateSettings() throws Exception {
        mockMvc.perform(patch("/api/v1/departments/1/settings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"allow_ops_bypass_prod_scale\":true}"))
                .andExpect(status().isForbidden());
    }
}