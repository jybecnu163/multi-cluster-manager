package com.cloudplatform.manager.service;

import com.cloudplatform.manager.base.BaseServiceTest;
import com.cloudplatform.manager.mapper.CompanyMapper;
import com.cloudplatform.manager.mapper.DepartmentMapper;
import com.cloudplatform.manager.model.entity.Company;
import com.cloudplatform.manager.service.impl.CompanyServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

class CompanyServiceTest extends BaseServiceTest {

    @Mock private CompanyMapper companyMapper;
    @Mock private DepartmentMapper departmentMapper;
    @InjectMocks private CompanyServiceImpl companyService;

    @Test
    @DisplayName("创建公司成功")
    void createCompanySuccess() {
        Company company = new Company();
        company.setName("新公司");
        when(companyMapper.insert(any())).thenReturn(1);
        assertDoesNotThrow(() -> companyService.createCompany(company.getName()));
    }

    @Test
    @DisplayName("删除无依赖公司成功")
    void deleteEmptyCompany() {
        when(departmentMapper.countByCompanyId(anyLong())).thenReturn(0L);
        when(companyMapper.deleteById(anyLong())).thenReturn(1);
        assertDoesNotThrow(() -> companyService.deleteCompany(1L));
    }

    @Test
    @DisplayName("删除有依赖公司抛出异常（409）")
    void deleteCompanyWithDepartments() {
        when(departmentMapper.countByCompanyId(anyLong())).thenReturn(3L);
        assertThrows(RuntimeException.class, () -> companyService.deleteCompany(1L));
    }

    @Test
    @DisplayName("获取公司列表")
    void listCompanies() {
        when(companyMapper.findAll()).thenReturn(List.of());
        var list = companyService.listCompanies();
        assertNotNull(list);
    }
}