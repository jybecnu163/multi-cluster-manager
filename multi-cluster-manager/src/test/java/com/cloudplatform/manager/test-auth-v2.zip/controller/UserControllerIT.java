package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseControllerIT;
import com.cloudplatform.manager.model.entity.User;
import com.cloudplatform.manager.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.ArrayList;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class UserControllerIT extends BaseControllerIT {

    @MockBean
    private UserService userService;

    @Test
    @WithMockUser(roles = {"ADMIN"})
    @DisplayName("创建成员返回201")
    void createUser() throws Exception {
        when(userService.createUser("张三", "zhangsan@test.com",
                "Zhangsan@123", new ArrayList<>(), 1L))
                .thenReturn(new User());
        mockMvc.perform(post("/api/v1/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"张三\",\"email\":\"zhangsan@test.com\",\"password\":\"Zhangsan@123\"}"))
                .andExpect(status().isCreated());
    }

    @Test
    @WithMockUser(roles = {"ADMIN"})
    @DisplayName("分配角色返回200")
    void assignRole() throws Exception {
        mockMvc.perform(put("/api/v1/users/1/roles")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_id\":3,\"env_type\":\"prod\",\"department_id\":1}"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = {"DEV"})
    @DisplayName("开发创建成员返回403")
    void devCreateUserForbidden() throws Exception {
        mockMvc.perform(post("/api/v1/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"test\",\"email\":\"t@t.com\",\"password\":\"12345678\"}"))
                .andExpect(status().isForbidden());
    }
}