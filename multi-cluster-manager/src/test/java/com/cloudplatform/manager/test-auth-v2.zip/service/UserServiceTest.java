package com.cloudplatform.manager.service;

import com.cloudplatform.manager.base.BaseServiceTest;
import com.cloudplatform.manager.mapper.UserDepartmentMapper;
import com.cloudplatform.manager.mapper.UserMapper;
import com.cloudplatform.manager.mapper.UserRoleMapper;
import com.cloudplatform.manager.model.entity.User;
import com.cloudplatform.manager.service.impl.UserServiceImpl;
import com.cloudplatform.manager.util.PasswordEncoder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class UserServiceTest extends BaseServiceTest {

    @Mock
    private UserMapper userMapper;
    @Mock
    private UserDepartmentMapper userDeptMapper;
    @Mock
    private UserRoleMapper userRoleMapper;
    @Mock
    private PasswordEncoder passwordEncoder;
    @InjectMocks
    private UserServiceImpl userService;

    @Test
    @DisplayName("创建用户并加密密码")
    void createUser() {
        User user = new User();
        user.setEmail("test@test.com");
        user.setPasswordHash("raw");
        when(passwordEncoder.encode(anyString())).thenReturn("hashed");
        when(userMapper.insert(any())).thenReturn(1);
        assertDoesNotThrow(() -> userService.createUser(user.getName(),
                user.getEmail(), user.getPasswordHash(), new ArrayList<>(), 1L));
        assertEquals("hashed", user.getPasswordHash());
    }

    @Test
    @DisplayName("分配角色")
    void assignRole() {
        when(userRoleMapper.insert(any())).thenReturn(1);
        assertDoesNotThrow(() -> userService.assignDepartments(1L, new ArrayList<>(), 1L));
    }
}