package com.cloudplatform.manager.security;

import com.cloudplatform.manager.base.BaseControllerIT;
import org.junit.jupiter.api.*;
import org.springframework.security.test.context.support.WithMockUser;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class PermissionIntegrationTest extends BaseControllerIT {

    @Test
    @WithMockUser(roles = {"OPS", "AUDITOR"})
    @DisplayName("多角色可以查看生产服务")
    void multiRoleCanViewProd() throws Exception {
        mockMvc.perform(post("/api/v1/services?env_type=prod"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = {"DEV"})
    @DisplayName("开发工程师不能在生产环境扩缩容")
    void devCannotScaleProd() throws Exception {
        mockMvc.perform(post("/api/v1/services/1/scale")
                .contentType("application/json")
                .content("{\"target_replicas\":2,\"reason\":\"test\"}"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(roles = {"OPS"})
    @DisplayName("运维工程师生产扩缩容返回202")
    void opsScaleProdAccepted() throws Exception {
        mockMvc.perform(post("/api/v1/services/1/scale")
                .contentType("application/json")
                .content("{\"target_replicas\":3,\"reason\":\"扩容\",\"ignore_approval\":false}"))
                .andExpect(status().isAccepted());
    }
}