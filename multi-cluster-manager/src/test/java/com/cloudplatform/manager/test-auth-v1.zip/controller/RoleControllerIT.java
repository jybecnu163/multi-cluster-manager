package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseIntegrationTest;
import com.cloudplatform.manager.service.RoleService;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class RoleControllerIT extends BaseIntegrationTest {
    @MockBean private RoleService roleService;

    @Test @WithMockUser(username = "admin", roles = {"ADMIN"})
    @DisplayName("查询角色列表")
    void getRoles() throws Exception {
        mockMvc.perform(get("/api/v1/roles"))
                .andExpect(status().isOk());
    }
    @Test @WithMockUser(username = "dev", roles = {"DEV"})
    @DisplayName("开发尝试提升自身为管理员返回403")
    void devElevateRole() throws Exception {
        mockMvc.perform(put("/api/v1/users/dev-user-id/roles")
                .contentType("application/json")
                .content("{\"role_id\":1,\"env_type\":\"all\",\"department_id\":\"1\"}"))
                .andExpect(status().isForbidden());
    }
}