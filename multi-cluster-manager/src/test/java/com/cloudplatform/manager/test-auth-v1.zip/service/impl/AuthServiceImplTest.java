package com.cloudplatform.manager.service.impl;

import com.cloudplatform.manager.mapper.UserMapper;
import com.cloudplatform.manager.model.entity.User;
import com.cloudplatform.manager.util.JwtUtil;
import com.cloudplatform.manager.util.PasswordEncoder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceImplTest {
    @Mock private UserMapper userRepository;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private JwtUtil jwtUtil;
    @InjectMocks private AuthServiceImpl authService;

    private User testUser;
    private final String email = "test@example.com";
    private final String password = "password123";
    private final String encodedPass = "encoded";
    private final String token = "jwt.token";

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail(email);
        testUser.setPasswordHash(encodedPass);
    }

    @Test
    void loginSuccess() {
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches(password, encodedPass)).thenReturn(true);
        when(jwtUtil.generateToken(testUser.getId(), email)).thenReturn(token);

        String result = authService.login(email, password);
        assertEquals(token, result);
    }

    @Test
    void loginInvalidEmail() {
        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> authService.login(email, password));
    }

    @Test
    void loginInvalidPassword() {
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches(password, encodedPass)).thenReturn(false);
        assertThrows(RuntimeException.class, () -> authService.login(email, password));
    }
}
