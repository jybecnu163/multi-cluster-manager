package com.cloudplatform.manager.security;

import com.cloudplatform.manager.base.BaseIntegrationTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class PermissionIntegrationTest extends BaseIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Nested
    @DisplayName("多角色组合权限")
    class MultiRoleTests {
        @Test
        @DisplayName("用户同时拥有运维和审计员角色，应可查看所有环境服务（权限并集）")
        void opsAndAuditorCanViewAll() throws Exception {
            String token = jwtUtil.generateToken(7L, "运维工程师,审计员");
            mockMvc.perform(post("/api/v1/services?env_type=prod")
                            .header("Authorization", bearer(token)))
                    .andExpect(status().isOk());
        }

        @Test
        @DisplayName("主部门与兼任部门权限隔离 - 仅可在有权限的部门环境操作")
        void primarySecondaryDepartmentIsolation() throws Exception {
            String token = jwtUtil.generateToken(6L, "开发工程师");
            mockMvc.perform(post("/api/v1/services/prod-service-id/scale")
                            .header("Authorization", bearer(token))
                            .contentType("application/json")
                            .content("{\"target_replicas\":3,\"reason\":\"test\"}"))
                    .andExpect(status().isForbidden());
        }
    }

    @Nested
    @DisplayName("环境级权限隔离")
    class EnvLevelIsolationTests {
        @Test
        @DisplayName("开发工程师仅能操作开发/测试环境服务，不能操作生产环境")
        void devCannotOperateProd() throws Exception {
            String devToken = jwtUtil.generateToken(4L, "开发工程师");
            mockMvc.perform(post("/api/v1/services/prod-service-id/scale")
                            .header("Authorization", bearer(devToken))
                            .contentType("application/json")
                            .content("{\"target_replicas\":2,\"reason\":\"test\"}"))
                    .andExpect(status().isForbidden());
        }

        @Test
        @DisplayName("运维工程师默认可在生产环境执行操作（需审批，但权限通过）")
        void opsCanOperateProdWithApproval() throws Exception {
            String opsToken = jwtUtil.generateToken(5L, "运维工程师");
            mockMvc.perform(post("/api/v1/services/prod-service-id/scale")
                            .header("Authorization", bearer(opsToken))
                            .contentType("application/json")
                            .content("{\"target_replicas\":3,\"reason\":\"扩容\",\"ignore_approval\":false}"))
                    .andExpect(status().isAccepted());
        }
    }

    @Nested
    @DisplayName("审批归属部门")
    class ApprovalDepartmentTest {
        @Test
        @DisplayName("操作服务归属部门B时，审批应由B部门主管负责，而非操作者主部门")
        void approvalBelongsToServiceDept() throws Exception {
        }
    }
}