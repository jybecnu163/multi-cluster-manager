package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseIntegrationTest;
import com.cloudplatform.manager.model.entity.Company;
import com.cloudplatform.manager.service.CompanyService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import java.time.Instant;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class CompanyControllerIT extends BaseIntegrationTest {

    @MockBean
    private CompanyService companyService;

    private final Long companyId = 1L;

    @Nested
    @DisplayName("正向测试 (系统管理员)")
    class AdminPositive {
        @Test
        @WithMockUser(username = "admin", roles = {"ADMIN"})
        @DisplayName("创建公司返回201")
        void createCompany() throws Exception {
            Company company = new Company();
            company.setId(companyId);
            company.setName("测试公司");
            company.setCreatedAt(Instant.now());
            when(companyService.createCompany(any())).thenReturn(company);

            mockMvc.perform(post("/api/v1/companies")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"name\":\"测试公司\"}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id").value(companyId))
                    .andExpect(jsonPath("$.name").value("测试公司"))
                    .andExpect(jsonPath("$.created_at").exists());
        }

        @Test
        @WithMockUser(username = "admin", roles = {"ADMIN"})
        @DisplayName("获取公司列表返回200")
        void listCompanies() throws Exception {
            when(companyService.listCompanies()).thenReturn(List.of());
            mockMvc.perform(get("/api/v1/companies"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$").isArray());
        }

        @Test
        @WithMockUser(username = "admin", roles = {"ADMIN"})
        @DisplayName("删除无依赖公司返回204")
        void deleteEmptyCompany() throws Exception {
            mockMvc.perform(delete("/api/v1/companies/" + companyId))
                    .andExpect(status().isNoContent());
        }
    }

    @Nested
    @DisplayName("负向测试 - 权限")
    class PermissionNegative {
        @Test
        @WithMockUser(username = "dev", roles = {"DEV"})
        @DisplayName("开发工程师创建公司返回403")
        void devCannotCreate() throws Exception {
            mockMvc.perform(post("/api/v1/companies")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"name\":\"test\"}"))
                    .andExpect(status().isForbidden());
        }

        @Test
        @DisplayName("未认证用户删除公司返回401")
        void deleteUnauthenticated() throws Exception {
            mockMvc.perform(delete("/api/v1/companies/" + companyId))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @WithMockUser(username = "admin", roles = {"ADMIN"})
        @DisplayName("删除有依赖的公司返回409")
        void deleteWithDependencies() throws Exception {
            when(companyService.deleteCompany(companyId)).thenThrow(new RuntimeException("dependencies exist"));
            mockMvc.perform(delete("/api/v1/companies/550e8400-e29b-41d4-a716-446655440002"))
                    .andExpect(status().isConflict());
        }
    }

    @Nested
    @DisplayName("负向测试 - 参数校验")
    class Validation {
        @Test
        @WithMockUser(username = "admin", roles = {"ADMIN"})
        @DisplayName("缺少name字段返回400")
        void missingName() throws Exception {
            mockMvc.perform(post("/api/v1/companies")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{}"))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @WithMockUser(username = "admin", roles = {"ADMIN"})
        @DisplayName("name超长返回400")
        void nameTooLong() throws Exception {
            mockMvc.perform(post("/api/v1/companies")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"name\":\"" + "A".repeat(129) + "\"}"))
                    .andExpect(status().isBadRequest());
        }
    }
}