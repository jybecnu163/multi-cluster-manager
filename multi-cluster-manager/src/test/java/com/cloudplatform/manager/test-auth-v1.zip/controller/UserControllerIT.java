package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseIntegrationTest;
import com.cloudplatform.manager.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class UserControllerIT extends BaseIntegrationTest {
    @MockBean
    private UserService userService;

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    @DisplayName("创建多部门用户并指定主部门返回201")
    void createMultiDeptUser() throws Exception {
        mockMvc.perform(post("/api/v1/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"张三\",\"email\":\"zhangsan@test.com\",\"password\":\"Zhangsan@123\",\"department_ids\":[\"1\",\"2\"],\"primary_department_id\":\"1\"}"))
                .andExpect(status().isCreated());
    }

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    @DisplayName("分配环境级角色成功")
    void assignRole() throws Exception {
        mockMvc.perform(put("/api/v1/users/550e8400-e29b-41d4-a716-446655440001/roles")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_id\":3,\"env_type\":\"prod\",\"department_id\":\"1\"}"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "dev", roles = {"DEV"})
    @DisplayName("开发工程师创建用户返回403")
    void devCannotCreateUser() throws Exception {
        mockMvc.perform(post("/api/v1/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"test\",\"email\":\"t@t.com\",\"password\":\"12345678\"}"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "user", roles = {"DEV"})
    @DisplayName("跨部门查看成员列表返回403")
    void crossDepartmentList() throws Exception {
        mockMvc.perform(get("/api/v1/users?department_id=3"))
                .andExpect(status().isForbidden());
    }
}