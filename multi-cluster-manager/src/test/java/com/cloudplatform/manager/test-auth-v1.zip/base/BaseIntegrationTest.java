package com.cloudplatform.manager.base;

import com.cloudplatform.manager.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@ActiveProfiles("test")
public abstract class BaseIntegrationTest {

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected JwtUtil jwtUtil;

    // 预生成不同角色Token
    protected String adminToken() {
        return jwtUtil.generateToken(1L, "系统管理员");
    }

    protected String directorToken() {
        return jwtUtil.generateToken(2L, "部门主管");
    }

    protected String opsToken() {
        return jwtUtil.generateToken(3L, "运维工程师");
    }

    protected String devToken() {
        return jwtUtil.generateToken(4L, "开发工程师");
    }

    protected String expiredToken() {
        return jwtUtil.generateToken(0L, "any");
    }

    protected String bearer(String token) {
        return "Bearer " + token;
    }
}