package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseIntegrationTest;
import com.cloudplatform.manager.service.DepartmentService;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class DepartmentControllerIT extends BaseIntegrationTest {
    @MockBean private DepartmentService departmentService;

    @Test @WithMockUser(username = "admin", roles = {"ADMIN"})
    @DisplayName("管理员创建部门返回201")
    void createDepartment() throws Exception {
        mockMvc.perform(post("/api/v1/departments")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"company_id\":\"550e8400-e29b-41d4-a716-446655440001\",\"name\":\"研发部\"}"))
                .andExpect(status().isCreated());
    }
    @Test @WithMockUser(username = "director", roles = {"DIRECTOR"})
    @DisplayName("部门主管获取本部门设置200")
    void getSettings() throws Exception {
        mockMvc.perform(get("/api/v1/departments/550e8400-e29b-41d4-a716-446655440001/settings"))
                .andExpect(status().isOk());
    }
    @Test @WithMockUser(username = "dev", roles = {"DEV"})
    @DisplayName("开发修改部门设置返回403")
    void devCannotUpdateSettings() throws Exception {
        mockMvc.perform(patch("/api/v1/departments/1/settings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"allow_ops_bypass_prod_scale\":true}"))
                .andExpect(status().isForbidden());
    }
}