package com.cloudplatform.manager.controller;

import com.cloudplatform.manager.base.BaseIntegrationTest;
import com.cloudplatform.manager.service.AuthService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class AuthControllerIT extends BaseIntegrationTest {

    @MockBean
    private AuthService authService;

    @Nested
    @DisplayName("正向测试")
    class Positive {
        @Test
        @DisplayName("合法凭据登录返回200及JWT")
        void loginSuccess() throws Exception {
            when(authService.login(any(), any())).thenReturn(
                    Map.of("access_token", "test-token", "token_type", "Bearer", "expires_in", 28800).toString()
            );
            mockMvc.perform(post("/api/v1/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"email\":\"admin@test.com\",\"password\":\"Admin@123456\"}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.access_token").isString())
                    .andExpect(jsonPath("$.token_type").value("Bearer"))
                    .andExpect(jsonPath("$.expires_in").isNumber());
        }
    }

    @Nested
    @DisplayName("负向测试 - 请求校验")
    class NegativeValidation {
        @Test
        @DisplayName("缺少email返回400")
        void missingEmail() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"password\":\"Admin@123456\"}"))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @DisplayName("邮箱格式非法返回400")
        void invalidEmail() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"email\":\"not-an-email\",\"password\":\"Admin@123456\"}"))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @DisplayName("密码长度不足8位返回400")
        void shortPassword() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"email\":\"admin@test.com\",\"password\":\"1234567\"}"))
                    .andExpect(status().isBadRequest());
        }
    }

    @Nested
    @DisplayName("负向测试 - 认证")
    class AuthNegative {
        @Test
        @DisplayName("无Token访问受保护资源返回401")
        void noToken() throws Exception {
            mockMvc.perform(post("/api/v1/companies"))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("过期Token返回401")
        void expiredToken() throws Exception {
            mockMvc.perform(post("/api/v1/companies")
                            .header("Authorization", bearer("test")))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("注销后Token失效返回401")
        void logoutInvalidatesToken() throws Exception {
            mockMvc.perform(post("/api/v1/auth/logout")
                            .header("Authorization", bearer(adminToken())))
                    .andExpect(status().isNoContent());
            mockMvc.perform(post("/api/v1/companies")
                            .header("Authorization", bearer(adminToken())))
                    .andExpect(status().isUnauthorized());
        }
    }

    @Nested
    @DisplayName("安全测试")
    class Security {
        @Test
        @DisplayName("弱密码处理（若无校验则记录）")
        void weakPassword() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"email\":\"admin@test.com\",\"password\":\"12345678\"}"))
                    .andExpect(status().isOk()); // 若无强度校验则通过，但需报告
        }

        @Test
        @DisplayName("SQL注入尝试被安全拒绝")
        void sqlInjection() throws Exception {
            mockMvc.perform(post("/api/v1/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"email\":\"admin@test.com\",\"password\":\"' OR '1'='1\"}"))
                    .andExpect(status().isUnauthorized());
        }
    }
}